# k3s-cluster

This repo contains YAML manifests to bootstrap a 3-node k3s Kubernetes cluster with:

- **MetalLB** for LoadBalancer support
- **Longhorn** for persistent config/app data
- **NFS** for media storage (e.g., TrueNAS)
- **Traefik** as reverse proxy
- **Sample App**: a whoami service with ingress and PVCs

## Folder Structure

```
k3s-cluster/
├── base/
│   ├── metallb-config.yaml
│   ├── longhorn-storageclass.yaml
│   ├── nfs/
│   │   └── nfs-pv-pvc.yaml
│   └── traefik/
│       └── whoami-deploy.yaml
```

## How to Use

1. **Clone and cd into the repo:**

```bash
git clone https://github.com/<your-username>/<your-repo>.git
cd k3s-cluster
```

2. **Deploy everything to your k3s cluster:**

```bash
kubectl apply -f base/metallb-config.yaml
kubectl apply -f base/longhorn-storageclass.yaml
kubectl apply -f base/nfs/
kubectl apply -f base/traefik/
```

3. **Edit `/etc/hosts`** if using local Ingress domain:

```
<MetalLB-IP> whoami.local
```

Then open `https://whoami.local` in your browser.

## Notes

- Replace `10.0.0.100` and `/mnt/media` in NFS config with your own TrueNAS values.
- Update `whoami.local` to your actual Ingress domain or use a wildcard DNS.

---
